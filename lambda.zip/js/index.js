const Alexa = require('alexa-sdk');

const SKILL_NAME = 'Sendator';
const HELP_MESSAGE = 'You can either tell me your state and issue, or you can exit. What can I do for you?';
const HELP_REPROMPT = 'What can I help you with?';
const STOP_MESSAGE = 'Welcome to Amazon, crusher of dreams.';


const handlers = {
  'LaunchRequest': function() {
    this.emit(':ask', HELP_REPROMPT);
  },
  'ContactSenatorIntent': function() {
    const stateSlot = this.event.request.intent.slots.State.value;
    const issueSlot = this.event.request.intent.slots.Issue.value;

    this.emit(':tell', "You live in " + stateSlot);
  },
};

exports.handler = function (event, context, callback) {
    const alexa = Alexa.handler(event, context, callback);
    alexa.registerHandlers(handlers);
    alexa.execute();
};
